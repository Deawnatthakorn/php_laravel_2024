<h3>For Loop</h3>
<?php
for ($i = 0; $i < 10; $i++) {
    echo $i;
}
?>

<h3>While Loop</h3>
<?php
$i = 0;
while ($i < 10) {
    echo $i;
    $i++;
}
?>

<h3>Do While Loop</h3>
<?php
$i = 0;
do {
    echo $i;
    $i++;
} while ($i < 10);
?>
    
