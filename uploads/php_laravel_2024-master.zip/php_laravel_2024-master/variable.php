<?php

$name = "John";
$age = 20;

echo $name;
echo $age;
?>
