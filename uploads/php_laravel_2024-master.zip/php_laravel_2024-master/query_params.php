<h3>Query Params</h3>
<?php
if (isset($_GET['name'])) {  // name=kob
    echo $_GET['name'];
}
?>
