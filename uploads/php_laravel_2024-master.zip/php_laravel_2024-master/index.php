<?php 
echo "This is Index Page";
?>