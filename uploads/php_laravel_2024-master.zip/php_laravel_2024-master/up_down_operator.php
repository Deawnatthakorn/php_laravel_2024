<?php
$x = 10;
?>

<h3>Up and Down Operator</h3>
<div>Up: <?php echo $x++; ?></div>
<div>Value: <?php echo $x; ?></div>
<div>Down: <?php echo $x--; ?></div>
<div>Value: <?php echo $x; ?></div>
