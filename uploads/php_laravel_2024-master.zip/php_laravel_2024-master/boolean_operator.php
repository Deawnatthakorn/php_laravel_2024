<?php
$x = 10;
$y = 20;
?>

<h3>Boolean Operators</h3>
<div>Equal: <?php echo $x == $y; ?></div>
<div>Not Equal: <?php echo $x != $y; ?></div>
<div>Greater Than: <?php echo $x > $y; ?></div>
<div>Less Than: <?php echo $x < $y; ?></div>

