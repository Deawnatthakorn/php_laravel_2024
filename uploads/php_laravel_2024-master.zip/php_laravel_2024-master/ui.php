<?php
$name = "John";
$age = 20;
?>

<h1>Name: <?php echo $name; ?></h1>
<h1>Age: <?php echo $age; ?></h1>
