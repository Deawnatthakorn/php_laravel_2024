<?php
$x = 10;
$y = 20;
?>

<h3>Arithmetic Operators</h3>
<div>Addition: <?php echo $x + $y; ?></div>
<div>Subtraction: <?php echo $x - $y; ?></div>
<div>Multiplication: <?php echo $x * $y; ?></div>
<div>Division: <?php echo $x / $y; ?></div>
<div>Modulus: <?php echo $x % $y; ?></div>
<div>Exponentiation: <?php echo $x ** $y; ?></div>
